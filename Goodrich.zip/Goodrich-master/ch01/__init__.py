__all__ = ['contains', 'count', 'factors1', 'factors2', 'factors3', 'fibonacci1', 'fibonacci2', 'gpa2', 'scale', 'sum1', 'sum2']
