__all__ = ['find_boyer_moore', 'find_brute', 'find_kmp', 'lcs', 'matrix_chain']
