__all__ = ['avl_tree', 'binary_search_tree', 'red_black_tree', 'splay_tree']
