'''What parameters should be sent to the range constructor,
   to produce a range with values 50, 60, 70, 80? '''
   
   
   
a = range( 50 , 90 , 10 )

# The code below is for testing purpose only

for n in a:
    print(n)