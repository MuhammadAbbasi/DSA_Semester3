'''What parameters should be sent to the range constructor,to 
   produce a range with values 8, 6, 4, 2, 0,−2,−4,−6,−8? '''
   

range( 8, -9, -2 )

# The code below is for testing purpose only
z = range( 8, -9, -2 )

for a in z:
    print(a)